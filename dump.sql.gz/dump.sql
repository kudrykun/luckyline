--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO rodosabc;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE categories (
    id integer NOT NULL,
    description text,
    parent_id integer,
    title character varying,
    slug character varying,
    is_items boolean
);


ALTER TABLE public.categories OWNER TO rodosabc;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO rodosabc;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- Name: finished_orders; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE finished_orders (
    id integer NOT NULL,
    order_number integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.finished_orders OWNER TO rodosabc;

--
-- Name: finished_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE finished_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.finished_orders_id_seq OWNER TO rodosabc;

--
-- Name: finished_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE finished_orders_id_seq OWNED BY finished_orders.id;


--
-- Name: friendly_id_slugs; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE friendly_id_slugs (
    id integer NOT NULL,
    slug character varying NOT NULL,
    sluggable_id integer NOT NULL,
    sluggable_type character varying(50),
    scope character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.friendly_id_slugs OWNER TO rodosabc;

--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE friendly_id_slugs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.friendly_id_slugs_id_seq OWNER TO rodosabc;

--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE friendly_id_slugs_id_seq OWNED BY friendly_id_slugs.id;


--
-- Name: item_colors; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE item_colors (
    id integer NOT NULL,
    item_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image_file_name character varying,
    image_content_type character varying,
    image_file_size integer,
    image_updated_at timestamp without time zone
);


ALTER TABLE public.item_colors OWNER TO rodosabc;

--
-- Name: item_colors_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE item_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_colors_id_seq OWNER TO rodosabc;

--
-- Name: item_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE item_colors_id_seq OWNED BY item_colors.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE items (
    id integer NOT NULL,
    title character varying,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    slug character varying,
    category_id integer,
    price text
);


ALTER TABLE public.items OWNER TO rodosabc;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO rodosabc;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE items_id_seq OWNED BY items.id;


--
-- Name: news_items; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE news_items (
    id integer NOT NULL,
    title character varying,
    text text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.news_items OWNER TO rodosabc;

--
-- Name: news_items_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE news_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_items_id_seq OWNER TO rodosabc;

--
-- Name: news_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE news_items_id_seq OWNED BY news_items.id;


--
-- Name: opinions; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE opinions (
    id integer NOT NULL,
    name character varying,
    text text,
    info text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    order_number integer
);


ALTER TABLE public.opinions OWNER TO rodosabc;

--
-- Name: opinions_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE opinions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.opinions_id_seq OWNER TO rodosabc;

--
-- Name: opinions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE opinions_id_seq OWNED BY opinions.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE orders (
    id integer NOT NULL,
    name character varying,
    phone_number character varying,
    email character varying,
    item_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO rodosabc;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO rodosabc;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE orders_id_seq OWNED BY orders.id;


--
-- Name: pictures; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE pictures (
    id integer NOT NULL,
    imageable_type character varying,
    imageable_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    image_file_name character varying,
    image_content_type character varying,
    image_file_size integer,
    image_updated_at timestamp without time zone
);


ALTER TABLE public.pictures OWNER TO rodosabc;

--
-- Name: pictures_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE pictures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pictures_id_seq OWNER TO rodosabc;

--
-- Name: pictures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE pictures_id_seq OWNED BY pictures.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO rodosabc;

--
-- Name: users; Type: TABLE; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO rodosabc;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: rodosabc
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO rodosabc;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rodosabc
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY finished_orders ALTER COLUMN id SET DEFAULT nextval('finished_orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY friendly_id_slugs ALTER COLUMN id SET DEFAULT nextval('friendly_id_slugs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY item_colors ALTER COLUMN id SET DEFAULT nextval('item_colors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY items ALTER COLUMN id SET DEFAULT nextval('items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY news_items ALTER COLUMN id SET DEFAULT nextval('news_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY opinions ALTER COLUMN id SET DEFAULT nextval('opinions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY orders ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY pictures ALTER COLUMN id SET DEFAULT nextval('pictures_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2016-10-15 22:45:58.432216	2016-10-15 22:45:58.432216
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY categories (id, description, parent_id, title, slug, is_items) FROM stdin;
184		\N	Кухонная мебель	kukhonnaia-mebel-0	t
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('categories_id_seq', 184, true);


--
-- Data for Name: finished_orders; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY finished_orders (id, order_number, created_at, updated_at) FROM stdin;
1	134	2016-12-02 10:35:03.573272	2016-12-02 10:35:03.573272
\.


--
-- Name: finished_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('finished_orders_id_seq', 1, true);


--
-- Data for Name: friendly_id_slugs; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY friendly_id_slugs (id, slug, sluggable_id, sluggable_type, scope, created_at) FROM stdin;
\.


--
-- Name: friendly_id_slugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('friendly_id_slugs_id_seq', 1, false);


--
-- Data for Name: item_colors; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY item_colors (id, item_id, created_at, updated_at, image_file_name, image_content_type, image_file_size, image_updated_at) FROM stdin;
\.


--
-- Name: item_colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('item_colors_id_seq', 2044, true);


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY items (id, title, description, created_at, updated_at, slug, category_id, price) FROM stdin;
1077	Лакированный МДФ двухсторонний ALVIC "Luxe" высокий глянец/матовый Испания		2016-12-03 14:35:04.195065	2016-12-03 14:35:04.195065	lakirovannyi-mdf-dvukhstoronnii-alvic-luxe-vysokii-glianetc-matovyi-ispaniia	184	<ul>\r\n<li>Без текстуры от 31 800 р. за 1 м.п.</li>\r\n<li>С текстурой от 36 975 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1078	Эко-плита CLEAF tss с термо-структурированной поверхностью Италия		2016-12-03 14:38:33.885313	2016-12-03 14:38:33.885313	eko-plita-cleaf-tss-s-termo-strukturirovannoi-poverkhnost-iu-italiia	184	<ul>\r\n<li>1-я группа от 29 395 р. за 1 м.п.</li>\r\n<li>2-я группа от 32 150 р. за 1 м.п</li>\r\n<li>3-я группа от 35 850 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1079	Эмаль двух-компонентная. Поверхность устойчивая к износу.		2016-12-03 14:40:05.364281	2016-12-03 14:40:05.364281	emal-dvukh-komponentnaia-poverkhnost-ustoichivaia-k-iznosu	184	<ul>\r\n<li>Матовая от 30 670 р. за 1 м.п.</li>\r\n<li>Глянцевая от 36 230 р. за 1 м.п</li>\r\n<li>Металлик от 39 800 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1080	Массив "Россия". Берёза - дуб.		2016-12-03 14:45:41.522731	2016-12-03 14:45:41.522731	massiv-rossiia-bereza-dub	184	<ul>\r\n <li>\r\n "Октавия" \r\n  <ul>\r\n   <li>Берёза от 37 500 р. за 1 м.п.</li>\r\n   <li>Дуб от 40 700 р. за 1 м.п.</li>\r\n  </ul>\r\n </li>\r\n <li>\r\n <li>\r\n "Лаура" \r\n  <ul>\r\n   <li>Берёза от 40 600 р. за 1 м.п.</li>\r\n  </ul>\r\n </li>\r\n </li>\r\n\r\n <li>\r\n<li>\r\n "Констанция" \r\n  <ul>\r\n   <li>Берёза от 47 450 р. за 1 м.п.</li>\r\n   <li>Дуб от 49 800 р. за 1 м.п.</li>\r\n  </ul>\r\n </li>\r\n </li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1074	МДФ - покрытие ПВХ		2016-12-03 14:25:39.555194	2016-12-03 14:25:39.555194	mdf-pokrytie-pvkh	184	<strong>Цены:</strong>\r\n<ul>\r\n<li>Матовая от 19 000 р. за 1 м.п.</li>\r\n<li>Глянцевая от 20 100 р. за 1 м.п</li>\r\n<li>Металлик-перламутр от 21 807 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1075	HPL - пластик "Arpa", "Lemark", "Melatone" Италия.		2016-12-03 14:29:00.1564	2016-12-03 14:29:00.1564	hpl-plastik-arpa-lemark-melatone-italiia	184	<ul>\r\n<li>Любые сочетания текстуры и цвета от 34 100 р. за 1 м.п.</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1076	Пластик АКРИЛОВЫЙ односторонний AGT глянцевый/матовый Турция		2016-12-03 14:32:08.394077	2016-12-03 14:32:08.394077	plastik-krilovyi-odnostoronnii-agt-gliantcevyi-matovyi-turtciia	184	<ul>\r\n<li>Без текстуры от 28 450 р. за 1 м.п.</li>\r\n<li>С текстурой от 34 530 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
1081	Массив "STIVAL". Италия.		2016-12-03 14:48:12.191556	2016-12-03 14:48:12.191556	massiv-stival-italiia	184	<ul>\r\n<li>"GT" от 32 800 р. за 1 м.п.</li>\r\n<li>"Скалли" от 41 500 р. за 1 м.п</li>\r\n<li>"Сандра-Ноче" от 52 300 р. за 1 м.п</li>\r\n</ul>\r\n\r\n<strong>В помплект входит:</strong>\r\n<ul>\r\n<li>Столешница пластик H=38 мм.</li>\r\n<li>Бортик пристеночный L=1000 мм.</li>\r\n<li>Цоколь наполный пластиковый L=1000 мм.</li>\r\n<li>Стол нижний 2-х дверный H=820 мм. Ширина 1000 мм.</li>\r\n<li>Шкаф верхний H=720 мм. Ширина 500 мм. - 2шт</li>\r\n</ul>
\.


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('items_id_seq', 1081, true);


--
-- Data for Name: news_items; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY news_items (id, title, text, created_at, updated_at) FROM stdin;
176	Новость #0	№0 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:21.945434	2016-11-28 13:27:21.945434
177	Новость #1	№1 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:23.147923	2016-11-28 13:27:23.147923
178	Новость #2	№2 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:24.285865	2016-11-28 13:27:24.285865
179	Новость #3	№3 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:25.412485	2016-11-28 13:27:25.412485
180	Новость #4	№4 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:26.571911	2016-11-28 13:27:26.571911
181	Новость #5	№5 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:27.720628	2016-11-28 13:27:27.720628
182	Новость #6	№6 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:28.847079	2016-11-28 13:27:28.847079
183	Новость #7	№7 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:29.98602	2016-11-28 13:27:29.98602
184	Новость #8	№8 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	2016-11-28 13:27:31.13313	2016-11-28 13:27:31.13313
\.


--
-- Name: news_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('news_items_id_seq', 184, true);


--
-- Data for Name: opinions; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY opinions (id, name, text, info, created_at, updated_at, order_number) FROM stdin;
323	Отзыв #1	№1 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #1	2016-11-28 13:27:32.479584	2016-11-28 13:27:32.479584	101
324	Отзыв #2	№2 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #2	2016-11-28 13:27:32.490507	2016-11-28 13:27:32.490507	102
325	Отзыв #3	№3 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #3	2016-11-28 13:27:32.501762	2016-11-28 13:27:32.501762	103
326	Отзыв #4	№4 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #4	2016-11-28 13:27:32.512603	2016-11-28 13:27:32.512603	104
327	Отзыв #5	№5 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #5	2016-11-28 13:27:32.52351	2016-11-28 13:27:32.52351	105
328	Отзыв #6	№6 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #6	2016-11-28 13:27:32.53483	2016-11-28 13:27:32.53483	106
329	Отзыв #7	№7 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #7	2016-11-28 13:27:32.545602	2016-11-28 13:27:32.545602	107
330	Отзыв #8	№8 Lorem ipsum dolor sit amet, consectetur adipiscing elit.\n                                Donec semper magna et ultricies semper. In maximus est a elit\n                                varius porttitor. Nunc vitae sapien facilisis, egestas magna sed,\n                                aliquet erat. Quisque nunc orci, gravida eu bibendum efficitur,\n                                laoreet sed ligula. Fusce varius fermentum nulla eu posuere.\n                                Pellentesque vel volutpat enim, semper sodales dui. Aenean cursus\n                                pharetra ultrices. Praesent sed odio nulla. Nunc sit amet risus\n                                et nulla consequat malesuada vel eu mauris. Fusce turpis nibh,\n                                venenatis ac sapien ac, tempor dapibus mi.	Info of opinion #8	2016-11-28 13:27:32.568292	2016-11-28 13:27:32.568292	108
\.


--
-- Name: opinions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('opinions_id_seq', 330, true);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY orders (id, name, phone_number, email, item_id, created_at, updated_at) FROM stdin;
101	Name #0	+7 916 770 48 60	email #0	\N	2016-11-28 13:27:32.60521	2016-11-28 13:27:32.60521
102	Name #1	+7 916 770 48 61	email #1	\N	2016-11-28 13:27:32.623331	2016-11-28 13:27:32.623331
103	Name #2	+7 916 770 48 62	email #2	\N	2016-11-28 13:27:32.634629	2016-11-28 13:27:32.634629
104	Name #3	+7 916 770 48 63	email #3	\N	2016-11-28 13:27:32.645341	2016-11-28 13:27:32.645341
105	Name #4	+7 916 770 48 64	email #4	\N	2016-11-28 13:27:32.656687	2016-11-28 13:27:32.656687
106	Name #5	+7 916 770 48 65	email #5	\N	2016-11-28 13:27:32.667913	2016-11-28 13:27:32.667913
107	Name #6	+7 916 770 48 66	email #6	\N	2016-11-28 13:27:32.678266	2016-11-28 13:27:32.678266
108	Name #7	+7 916 770 48 67	email #7	\N	2016-11-28 13:27:32.71192	2016-11-28 13:27:32.71192
109	Name #8	+7 916 770 48 68	email #8	\N	2016-11-28 13:27:32.722846	2016-11-28 13:27:32.722846
110	Сергей	89167704868	\N	\N	2016-12-02 10:00:59.157021	2016-12-02 10:00:59.157021
111	Сергей	89167704868	\N	\N	2016-12-02 10:01:41.817587	2016-12-02 10:01:41.817587
\.


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('orders_id_seq', 112, true);


--
-- Data for Name: pictures; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY pictures (id, imageable_type, imageable_id, created_at, updated_at, image_file_name, image_content_type, image_file_size, image_updated_at) FROM stdin;
3589	NewsItem	176	2016-11-28 13:27:22.213816	2016-11-28 13:27:22.213816	news1.jpg	image/jpeg	26792	2016-11-28 13:27:21.976291
3590	NewsItem	176	2016-11-28 13:27:22.498032	2016-11-28 13:27:22.498032	news2.jpg	image/jpeg	47071	2016-11-28 13:27:22.256778
3591	NewsItem	176	2016-11-28 13:27:22.784332	2016-11-28 13:27:22.784332	news3.jpg	image/jpeg	40927	2016-11-28 13:27:22.543545
3592	NewsItem	176	2016-11-28 13:27:23.108454	2016-11-28 13:27:23.108454	news4.jpg	image/jpeg	46641	2016-11-28 13:27:22.846328
3593	NewsItem	177	2016-11-28 13:27:23.405215	2016-11-28 13:27:23.405215	news1.jpg	image/jpeg	26792	2016-11-28 13:27:23.161286
3594	NewsItem	177	2016-11-28 13:27:23.676505	2016-11-28 13:27:23.676505	news2.jpg	image/jpeg	47071	2016-11-28 13:27:23.449306
3595	NewsItem	177	2016-11-28 13:27:23.975222	2016-11-28 13:27:23.975222	news3.jpg	image/jpeg	40927	2016-11-28 13:27:23.714459
3596	NewsItem	177	2016-11-28 13:27:24.249696	2016-11-28 13:27:24.249696	news4.jpg	image/jpeg	46641	2016-11-28 13:27:24.012037
3597	NewsItem	178	2016-11-28 13:27:24.550232	2016-11-28 13:27:24.550232	news1.jpg	image/jpeg	26792	2016-11-28 13:27:24.300291
3598	NewsItem	178	2016-11-28 13:27:24.824997	2016-11-28 13:27:24.824997	news2.jpg	image/jpeg	47071	2016-11-28 13:27:24.597316
3599	NewsItem	178	2016-11-28 13:27:25.115436	2016-11-28 13:27:25.115436	news3.jpg	image/jpeg	40927	2016-11-28 13:27:24.87346
3600	NewsItem	178	2016-11-28 13:27:25.370327	2016-11-28 13:27:25.370327	news4.jpg	image/jpeg	46641	2016-11-28 13:27:25.150003
3601	NewsItem	179	2016-11-28 13:27:25.672634	2016-11-28 13:27:25.672634	news1.jpg	image/jpeg	26792	2016-11-28 13:27:25.437524
3602	NewsItem	179	2016-11-28 13:27:25.960754	2016-11-28 13:27:25.960754	news2.jpg	image/jpeg	47071	2016-11-28 13:27:25.72334
3603	NewsItem	179	2016-11-28 13:27:26.22671	2016-11-28 13:27:26.22671	news3.jpg	image/jpeg	40927	2016-11-28 13:27:26.000668
3604	NewsItem	179	2016-11-28 13:27:26.525982	2016-11-28 13:27:26.525982	news4.jpg	image/jpeg	46641	2016-11-28 13:27:26.283705
3605	NewsItem	180	2016-11-28 13:27:26.818251	2016-11-28 13:27:26.818251	news1.jpg	image/jpeg	26792	2016-11-28 13:27:26.58576
3606	NewsItem	180	2016-11-28 13:27:27.093343	2016-11-28 13:27:27.093343	news2.jpg	image/jpeg	47071	2016-11-28 13:27:26.862516
3607	NewsItem	180	2016-11-28 13:27:27.37918	2016-11-28 13:27:27.37918	news3.jpg	image/jpeg	40927	2016-11-28 13:27:27.137928
3608	NewsItem	180	2016-11-28 13:27:27.680516	2016-11-28 13:27:27.680516	news4.jpg	image/jpeg	46641	2016-11-28 13:27:27.436852
3609	NewsItem	181	2016-11-28 13:27:27.977364	2016-11-28 13:27:27.977364	news1.jpg	image/jpeg	26792	2016-11-28 13:27:27.734771
3610	NewsItem	181	2016-11-28 13:27:28.263837	2016-11-28 13:27:28.263837	news2.jpg	image/jpeg	47071	2016-11-28 13:27:28.021166
3611	NewsItem	181	2016-11-28 13:27:28.534564	2016-11-28 13:27:28.534564	news3.jpg	image/jpeg	40927	2016-11-28 13:27:28.297091
3612	NewsItem	181	2016-11-28 13:27:28.81086	2016-11-28 13:27:28.81086	news4.jpg	image/jpeg	46641	2016-11-28 13:27:28.573417
3613	NewsItem	182	2016-11-28 13:27:29.093669	2016-11-28 13:27:29.093669	news1.jpg	image/jpeg	26792	2016-11-28 13:27:28.859354
3614	NewsItem	182	2016-11-28 13:27:29.375696	2016-11-28 13:27:29.375696	news2.jpg	image/jpeg	47071	2016-11-28 13:27:29.136756
3615	NewsItem	182	2016-11-28 13:27:29.656313	2016-11-28 13:27:29.656313	news3.jpg	image/jpeg	40927	2016-11-28 13:27:29.435075
3616	NewsItem	182	2016-11-28 13:27:29.941984	2016-11-28 13:27:29.941984	news4.jpg	image/jpeg	46641	2016-11-28 13:27:29.700431
3617	NewsItem	183	2016-11-28 13:27:30.232502	2016-11-28 13:27:30.232502	news1.jpg	image/jpeg	26792	2016-11-28 13:27:29.997259
3618	NewsItem	183	2016-11-28 13:27:30.526106	2016-11-28 13:27:30.526106	news2.jpg	image/jpeg	47071	2016-11-28 13:27:30.285189
3619	NewsItem	183	2016-11-28 13:27:30.817605	2016-11-28 13:27:30.817605	news3.jpg	image/jpeg	40927	2016-11-28 13:27:30.57296
3620	NewsItem	183	2016-11-28 13:27:31.099921	2016-11-28 13:27:31.099921	news4.jpg	image/jpeg	46641	2016-11-28 13:27:30.859907
3621	NewsItem	184	2016-11-28 13:27:31.382721	2016-11-28 13:27:31.382721	news1.jpg	image/jpeg	26792	2016-11-28 13:27:31.146225
3622	NewsItem	184	2016-11-28 13:27:31.675402	2016-11-28 13:27:31.675402	news2.jpg	image/jpeg	47071	2016-11-28 13:27:31.422632
3623	NewsItem	184	2016-11-28 13:27:31.94779	2016-11-28 13:27:31.94779	news3.jpg	image/jpeg	40927	2016-11-28 13:27:31.721658
3624	NewsItem	184	2016-11-28 13:27:32.243118	2016-11-28 13:27:32.243118	news4.jpg	image/jpeg	46641	2016-11-28 13:27:31.997943
3625	Item	1074	2016-12-03 14:25:47.211552	2016-12-03 14:25:47.211552	mdf-7.JPG	image/jpeg	4913969	2016-12-03 14:25:39.77117
3626	Item	1074	2016-12-03 14:25:53.447479	2016-12-03 14:25:53.447479	mdf-6.jpg	image/jpeg	5376972	2016-12-03 14:25:47.590296
3627	Item	1074	2016-12-03 14:25:59.704915	2016-12-03 14:25:59.704915	mdf-5.jpg	image/jpeg	5129960	2016-12-03 14:25:53.67115
3628	Item	1074	2016-12-03 14:26:05.720501	2016-12-03 14:26:05.720501	mdf-4.jpg	image/jpeg	4413186	2016-12-03 14:25:59.925903
3629	Item	1074	2016-12-03 14:26:13.046091	2016-12-03 14:26:13.046091	mdf-3.jpg	image/jpeg	4452183	2016-12-03 14:26:05.902263
3630	Item	1074	2016-12-03 14:26:15.453805	2016-12-03 14:26:15.453805	mdf-2.jpg	image/jpeg	1614713	2016-12-03 14:26:13.216664
3631	Item	1074	2016-12-03 14:26:17.726633	2016-12-03 14:26:17.726633	mdf-1.jpg	image/jpeg	1607194	2016-12-03 14:26:15.523185
3632	Item	1075	2016-12-03 14:29:05.931207	2016-12-03 14:29:05.931207	hpl-6.jpg	image/jpeg	2842806	2016-12-03 14:29:01.353938
3633	Item	1075	2016-12-03 14:29:10.493994	2016-12-03 14:29:10.493994	hpl-5.jpg	image/jpeg	2995998	2016-12-03 14:29:06.199648
3634	Item	1075	2016-12-03 14:29:16.817079	2016-12-03 14:29:16.817079	hpl-4.jpg	image/jpeg	5491324	2016-12-03 14:29:10.678936
3635	Item	1075	2016-12-03 14:29:22.948408	2016-12-03 14:29:22.948408	hpl-3.jpg	image/jpeg	5152978	2016-12-03 14:29:16.980043
3636	Item	1075	2016-12-03 14:29:29.060187	2016-12-03 14:29:29.060187	hpl-2.jpg	image/jpeg	5370232	2016-12-03 14:29:23.208541
3637	Item	1075	2016-12-03 14:29:30.824723	2016-12-03 14:29:30.824723	hpl-1.jpg	image/jpeg	1315890	2016-12-03 14:29:29.295461
3638	Item	1076	2016-12-03 14:32:12.624664	2016-12-03 14:32:12.624664	acril-4.jpg	image/jpeg	2379415	2016-12-03 14:32:08.431691
3639	Item	1076	2016-12-03 14:32:16.888624	2016-12-03 14:32:16.888624	acril-3.jpg	image/jpeg	2336698	2016-12-03 14:32:12.746929
3640	Item	1076	2016-12-03 14:32:21.159057	2016-12-03 14:32:21.159057	acril-2.jpg	image/jpeg	2535174	2016-12-03 14:32:17.053128
3641	Item	1076	2016-12-03 14:32:21.946404	2016-12-03 14:32:21.946404	acril-1.jpg	image/jpeg	257792	2016-12-03 14:32:21.300511
3642	Item	1077	2016-12-03 14:35:04.640948	2016-12-03 14:35:04.640948	2mdf-8.jpg	image/jpeg	77170	2016-12-03 14:35:04.230452
3643	Item	1077	2016-12-03 14:35:05.150826	2016-12-03 14:35:05.150826	2mdf-7.jpg	image/jpeg	64411	2016-12-03 14:35:04.691745
3644	Item	1077	2016-12-03 14:35:05.636923	2016-12-03 14:35:05.636923	2mdf-6.jpg	image/jpeg	31116	2016-12-03 14:35:05.266769
3645	Item	1077	2016-12-03 14:35:06.079024	2016-12-03 14:35:06.079024	2mdf-5.jpg	image/jpeg	86704	2016-12-03 14:35:05.686556
3646	Item	1077	2016-12-03 14:35:06.5134	2016-12-03 14:35:06.5134	2mdf-4.jpg	image/jpeg	89056	2016-12-03 14:35:06.128312
3647	Item	1077	2016-12-03 14:35:06.940747	2016-12-03 14:35:06.940747	2mdf-3.jpg	image/jpeg	101498	2016-12-03 14:35:06.55873
3648	Item	1077	2016-12-03 14:35:07.435191	2016-12-03 14:35:07.435191	2mdf-2.jpg	image/jpeg	45794	2016-12-03 14:35:07.05644
3649	Item	1077	2016-12-03 14:35:07.831968	2016-12-03 14:35:07.831968	2mdf-1.jpg	image/jpeg	44246	2016-12-03 14:35:07.475377
3650	Item	1078	2016-12-03 14:38:38.308751	2016-12-03 14:38:38.308751	plita-2.jpg	image/jpeg	2478315	2016-12-03 14:38:33.923024
3651	Item	1078	2016-12-03 14:38:42.853504	2016-12-03 14:38:42.853504	plita-1.jpg	image/jpeg	2811232	2016-12-03 14:38:38.541134
3652	Item	1079	2016-12-03 14:40:06.333497	2016-12-03 14:40:06.333497	emal-3.jpg	image/jpeg	110375	2016-12-03 14:40:05.405804
3653	Item	1079	2016-12-03 14:40:07.131183	2016-12-03 14:40:07.131183	emal-2.jpg	image/jpeg	69076	2016-12-03 14:40:06.385469
3654	Item	1079	2016-12-03 14:40:07.916937	2016-12-03 14:40:07.916937	emal-1.jpg	image/jpeg	79301	2016-12-03 14:40:07.180792
3655	Item	1080	2016-12-03 14:45:43.484431	2016-12-03 14:45:43.484431	massiv-8.jpg	image/jpeg	189569	2016-12-03 14:45:42.37021
3656	Item	1080	2016-12-03 14:45:44.268518	2016-12-03 14:45:44.268518	massiv-7.jpg	image/jpeg	114448	2016-12-03 14:45:43.612774
3657	Item	1080	2016-12-03 14:45:44.977255	2016-12-03 14:45:44.977255	massiv-6.jpg	image/jpeg	194181	2016-12-03 14:45:44.315261
3658	Item	1080	2016-12-03 14:45:51.275211	2016-12-03 14:45:51.275211	massiv-5.jpg	image/jpeg	5644303	2016-12-03 14:45:45.047428
3659	Item	1080	2016-12-03 14:45:57.826314	2016-12-03 14:45:57.826314	massiv-4.jpg	image/jpeg	5468870	2016-12-03 14:45:51.448766
3660	Item	1080	2016-12-03 14:46:04.999756	2016-12-03 14:46:04.999756	massiv-3.jpg	image/jpeg	4781090	2016-12-03 14:45:57.967274
3661	Item	1080	2016-12-03 14:46:06.830968	2016-12-03 14:46:06.830968	massiv-2.jpg	image/jpeg	1658297	2016-12-03 14:46:05.16275
3662	Item	1080	2016-12-03 14:46:07.610903	2016-12-03 14:46:07.610903	massiv-1.jpg	image/jpeg	189569	2016-12-03 14:46:06.946913
3663	Item	1081	2016-12-03 14:48:18.007527	2016-12-03 14:48:18.007527	italia-4.jpg	image/jpeg	2282499	2016-12-03 14:48:12.578024
3664	Item	1081	2016-12-03 14:48:23.29944	2016-12-03 14:48:23.29944	italia-3.jpg	image/jpeg	2345288	2016-12-03 14:48:18.171169
3665	Item	1081	2016-12-03 14:48:27.801748	2016-12-03 14:48:27.801748	italia-2.jpg	image/jpeg	2311154	2016-12-03 14:48:23.427777
3666	Item	1081	2016-12-03 14:48:32.952816	2016-12-03 14:48:32.952816	italia-1.jpg	image/jpeg	2369716	2016-12-03 14:48:27.918917
\.


--
-- Name: pictures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('pictures_id_seq', 3666, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY schema_migrations (version) FROM stdin;
20161015224615
20161015224704
20161015224718
20161015224737
20161015225021
20161016130906
20161016131316
20161016132205
20161016222933
20161016224202
20161016225527
20161016225921
20161016232831
20161017005835
20161017010246
20161017063858
20161017063914
20161018133106
20161019205432
20161021123548
20161119111153
20161119111301
20161119111307
20161119112051
20161119112427
20161119112658
20161119120643
20161119122201
20161119144043
20161120173535
20161120184227
20161120184304
20161130195306
20161202101303
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rodosabc
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at) FROM stdin;
0	serega@gmail.com	$2a$11$z0eIAXezmkjtYbeJGqRcked2VXtByheU3UGu4dMWis4ae.K6nD6vG	\N	\N	\N	4	2016-12-03 11:26:06.666118	2016-12-02 10:00:16.363339	127.0.0.1	127.0.0.1	2016-11-30 22:41:33.203801	2016-12-03 11:26:06.67073
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rodosabc
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: categories_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: finished_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY finished_orders
    ADD CONSTRAINT finished_orders_pkey PRIMARY KEY (id);


--
-- Name: friendly_id_slugs_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY friendly_id_slugs
    ADD CONSTRAINT friendly_id_slugs_pkey PRIMARY KEY (id);


--
-- Name: item_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY item_colors
    ADD CONSTRAINT item_colors_pkey PRIMARY KEY (id);


--
-- Name: items_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: news_items_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY news_items
    ADD CONSTRAINT news_items_pkey PRIMARY KEY (id);


--
-- Name: opinions_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY opinions
    ADD CONSTRAINT opinions_pkey PRIMARY KEY (id);


--
-- Name: orders_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: pictures_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY pictures
    ADD CONSTRAINT pictures_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: rodosabc; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_categories_on_parent_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_categories_on_parent_id ON categories USING btree (parent_id);


--
-- Name: index_categories_on_slug; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE UNIQUE INDEX index_categories_on_slug ON categories USING btree (slug);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type ON friendly_id_slugs USING btree (slug, sluggable_type);


--
-- Name: index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE UNIQUE INDEX index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope ON friendly_id_slugs USING btree (slug, sluggable_type, scope);


--
-- Name: index_friendly_id_slugs_on_sluggable_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_id ON friendly_id_slugs USING btree (sluggable_id);


--
-- Name: index_friendly_id_slugs_on_sluggable_type; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_friendly_id_slugs_on_sluggable_type ON friendly_id_slugs USING btree (sluggable_type);


--
-- Name: index_item_colors_on_item_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_item_colors_on_item_id ON item_colors USING btree (item_id);


--
-- Name: index_items_on_category_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_items_on_category_id ON items USING btree (category_id);


--
-- Name: index_items_on_slug; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE UNIQUE INDEX index_items_on_slug ON items USING btree (slug);


--
-- Name: index_orders_on_item_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_orders_on_item_id ON orders USING btree (item_id);


--
-- Name: index_pictures_on_imageable_type_and_imageable_id; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE INDEX index_pictures_on_imageable_type_and_imageable_id ON pictures USING btree (imageable_type, imageable_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: rodosabc; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: fk_rails_7953c70fdc; Type: FK CONSTRAINT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY item_colors
    ADD CONSTRAINT fk_rails_7953c70fdc FOREIGN KEY (item_id) REFERENCES items(id);


--
-- Name: fk_rails_89fb86dc8b; Type: FK CONSTRAINT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY items
    ADD CONSTRAINT fk_rails_89fb86dc8b FOREIGN KEY (category_id) REFERENCES categories(id);


--
-- Name: fk_rails_fc971cd604; Type: FK CONSTRAINT; Schema: public; Owner: rodosabc
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_rails_fc971cd604 FOREIGN KEY (item_id) REFERENCES items(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

